/*
 * ============================================================
 *  Bilal_4WD_Car — ESP32 BLE UART + TB6612FNG
 *  Compatible with Cyber RC Controller Flutter App
 * 
 *  Command Protocol (matches commands.dart):
 *   F/B/L/R/G/H/I/J = movement directions
 *   S               = stop
 *   U/u             = headlight on/off
 *   V/v             = taillight on/off
 *   W/w             = parking lights on/off
 *   X/x             = hazard lights on/off
 *   Y               = horn
 *   Z               = special function
 *   1-4             = custom functions
 * 
 *  Telemetry sent back to app every 500ms:
 *   "B:85,S:20"  (battery %, speed km/h)
 * ============================================================
 */

#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>
#include <BLE2902.h>

// ── BLE UUIDs (Nordic UART Service) ──────────────────────────
#define SERVICE_UUID        "6E400001-B5A3-F393-E0A9-E50E24DCCA9E"
#define CHARACTERISTIC_UUID_RX "6E400002-B5A3-F393-E0A9-E50E24DCCA9E"
#define CHARACTERISTIC_UUID_TX "6E400003-B5A3-F393-E0A9-E50E24DCCA9E"

// ── Motor A (Left motors) ─────────────────────────────────────
#define PWMA  25    // PWM speed control
#define AIN1  26    // Direction pin 1
#define AIN2  27    // Direction pin 2

// ── Motor B (Right motors) ────────────────────────────────────
#define PWMB  14    // PWM speed control
#define BIN1  12    // Direction pin 1
#define BIN2  13    // Direction pin 2

// ── TB6612FNG Standby ─────────────────────────────────────────
#define STBY  33    // LOW = standby, HIGH = active

// ── Accessories ───────────────────────────────────────────────
#define HEADLIGHT  32
#define TAILLIGHT  4
#define HORN_PIN   2

// ── Speed setting (0–255) ─────────────────────────────────────
int driveSpeed  = 200;
int turnSpeed   = 160;

// ── BLE state ─────────────────────────────────────────────────
BLECharacteristic* pTxChar;
bool deviceConnected = false;
String lastCmd = "";
unsigned long lastTelemetry = 0;

// ── Simulated telemetry (replace with real ADC reads) ─────────
float batteryPct = 85.0;
float speedKmh   = 0.0;

// ─────────────────────────────────────────────────────────────
//  BLE Callbacks
// ─────────────────────────────────────────────────────────────
class ServerCallbacks : public BLEServerCallbacks {
  void onConnect(BLEServer* s)    { deviceConnected = true;  digitalWrite(2, HIGH); }
  void onDisconnect(BLEServer* s) { deviceConnected = false; stopAll(); BLEDevice::startAdvertising(); }
};

class RxCallbacks : public BLECharacteristicCallbacks {
  void onWrite(BLECharacteristic* c) {
    std::string val = c->getValue();
    if (val.length() > 0) {
      processCommand(String(val.c_str()));
    }
  }
};

// ─────────────────────────────────────────────────────────────
//  Motor helpers
// ─────────────────────────────────────────────────────────────
void motorA(int speed) {   // positive = forward, negative = backward
  analogWrite(PWMA, abs(speed));
  digitalWrite(AIN1, speed >= 0 ? HIGH : LOW);
  digitalWrite(AIN2, speed >= 0 ? LOW  : HIGH);
}

void motorB(int speed) {
  analogWrite(PWMB, abs(speed));
  digitalWrite(BIN1, speed >= 0 ? HIGH : LOW);
  digitalWrite(BIN2, speed >= 0 ? LOW  : HIGH);
}

void stopAll() {
  analogWrite(PWMA, 0);
  analogWrite(PWMB, 0);
  speedKmh = 0;
}

void driveForward()       { digitalWrite(STBY, HIGH); motorA(driveSpeed);  motorB(driveSpeed);  speedKmh = 20; }
void driveBackward()      { digitalWrite(STBY, HIGH); motorA(-driveSpeed); motorB(-driveSpeed); speedKmh = 10; }
void spinLeft()           { digitalWrite(STBY, HIGH); motorA(-turnSpeed);  motorB(turnSpeed);   speedKmh = 5;  }
void spinRight()          { digitalWrite(STBY, HIGH); motorA(turnSpeed);   motorB(-turnSpeed);  speedKmh = 5;  }
void driveForwardLeft()   { digitalWrite(STBY, HIGH); motorA(driveSpeed/2); motorB(driveSpeed); speedKmh = 15; }
void driveForwardRight()  { digitalWrite(STBY, HIGH); motorA(driveSpeed);  motorB(driveSpeed/2); speedKmh = 15; }
void driveBackwardLeft()  { digitalWrite(STBY, HIGH); motorA(-driveSpeed/2); motorB(-driveSpeed); speedKmh = 8; }
void driveBackwardRight() { digitalWrite(STBY, HIGH); motorA(-driveSpeed); motorB(-driveSpeed/2); speedKmh = 8; }

// ─────────────────────────────────────────────────────────────
//  Command processor
// ─────────────────────────────────────────────────────────────
void processCommand(String cmd) {
  cmd.trim();
  if (cmd == lastCmd) return;   // debounce repeated commands
  lastCmd = cmd;
  Serial.println("CMD: " + cmd);

  // ── Movement ──────────────────────────────────────────────
  if      (cmd == "F") driveForward();
  else if (cmd == "B") driveBackward();
  else if (cmd == "L") spinLeft();
  else if (cmd == "R") spinRight();
  else if (cmd == "G") driveForwardLeft();
  else if (cmd == "H") driveForwardRight();
  else if (cmd == "I") driveBackwardLeft();
  else if (cmd == "J") driveBackwardRight();
  else if (cmd == "S") { stopAll(); digitalWrite(STBY, LOW); }

  // ── Lights ────────────────────────────────────────────────
  else if (cmd == "U") digitalWrite(HEADLIGHT, HIGH);
  else if (cmd == "u") digitalWrite(HEADLIGHT, LOW);
  else if (cmd == "V") digitalWrite(TAILLIGHT, HIGH);
  else if (cmd == "v") digitalWrite(TAILLIGHT, LOW);

  // ── Horn ──────────────────────────────────────────────────
  else if (cmd == "Y") { tone(HORN_PIN, 800, 200); }

  // ── Speed presets ─────────────────────────────────────────
  else if (cmd == "q") driveSpeed = 120;
  else if (cmd == "e") driveSpeed = 180;
  else if (cmd == "r") driveSpeed = 255;
}

// ─────────────────────────────────────────────────────────────
//  Telemetry sender
// ─────────────────────────────────────────────────────────────
void sendTelemetry() {
  if (!deviceConnected) return;
  // TODO: read real ADC for battery: batteryPct = analogRead(35) * (100.0 / 4095.0) * voltage_divider_factor;
  String payload = "B:" + String((int)batteryPct) + ",S:" + String((int)speedKmh);
  pTxChar->setValue(payload.c_str());
  pTxChar->notify();
}

// ─────────────────────────────────────────────────────────────
//  SETUP
// ─────────────────────────────────────────────────────────────
void setup() {
  Serial.begin(115200);

  // Pin modes
  pinMode(PWMA, OUTPUT); pinMode(AIN1, OUTPUT); pinMode(AIN2, OUTPUT);
  pinMode(PWMB, OUTPUT); pinMode(BIN1, OUTPUT); pinMode(BIN2, OUTPUT);
  pinMode(STBY, OUTPUT);
  pinMode(HEADLIGHT, OUTPUT);
  pinMode(TAILLIGHT, OUTPUT);

  digitalWrite(STBY, LOW);  // start in standby

  // BLE init
  BLEDevice::init("Bilal_4WD_Car");
  BLEServer* server = BLEDevice::createServer();
  server->setCallbacks(new ServerCallbacks());

  BLEService* svc = server->createService(SERVICE_UUID);

  // TX characteristic (ESP32 → Phone)
  pTxChar = svc->createCharacteristic(
    CHARACTERISTIC_UUID_TX,
    BLECharacteristic::PROPERTY_NOTIFY
  );
  pTxChar->addDescriptor(new BLE2902());

  // RX characteristic (Phone → ESP32)
  BLECharacteristic* pRxChar = svc->createCharacteristic(
    CHARACTERISTIC_UUID_RX,
    BLECharacteristic::PROPERTY_WRITE | BLECharacteristic::PROPERTY_WRITE_NR
  );
  pRxChar->setCallbacks(new RxCallbacks());

  svc->start();
  BLEAdvertising* adv = BLEDevice::getAdvertising();
  adv->addServiceUUID(SERVICE_UUID);
  adv->setScanResponse(true);
  BLEDevice::startAdvertising();

  Serial.println("BLE ready — Bilal_4WD_Car advertising");
}

// ─────────────────────────────────────────────────────────────
//  LOOP
// ─────────────────────────────────────────────────────────────
void loop() {
  // Send telemetry every 500ms
  if (millis() - lastTelemetry > 500) {
    sendTelemetry();
    lastTelemetry = millis();
  }
  delay(10);
}
