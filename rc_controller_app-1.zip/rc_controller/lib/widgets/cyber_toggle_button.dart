// lib/widgets/cyber_toggle_button.dart
import 'package:flutter/material.dart';
import 'package:vibration/vibration.dart';
import '../config/commands.dart';

class CyberToggleButton extends StatefulWidget {
  final IconData icon;
  final String label;
  final String cmdOn;
  final String cmdOff;
  final bool isToggle;        // true = latching toggle, false = momentary
  final ValueChanged<String> onSend;
  final Color? activeColor;

  const CyberToggleButton({
    super.key,
    required this.icon,
    required this.label,
    required this.cmdOn,
    required this.cmdOff,
    required this.onSend,
    this.isToggle = true,
    this.activeColor,
  });

  @override
  State<CyberToggleButton> createState() => _CyberToggleButtonState();
}

class _CyberToggleButtonState extends State<CyberToggleButton>
    with SingleTickerProviderStateMixin {
  bool _on = false;
  late AnimationController _anim;
  late Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _anim = AnimationController(vsync: this, duration: const Duration(milliseconds: 120));
    _scale = Tween(begin: 1.0, end: 0.88).animate(
      CurvedAnimation(parent: _anim, curve: Curves.easeInOut),
    );
  }

  Future<void> _tap() async {
    await _anim.forward();
    await _anim.reverse();

    final hasVib = await Vibration.hasVibrator() ?? false;
    if (hasVib) Vibration.vibrate(duration: 30);

    if (widget.isToggle) {
      setState(() => _on = !_on);
      widget.onSend(_on ? widget.cmdOn : widget.cmdOff);
    } else {
      widget.onSend(widget.cmdOn);
    }
  }

  @override
  Widget build(BuildContext context) {
    final color = widget.activeColor ?? const Color(CyberTheme.accent);

    return GestureDetector(
      onTap: _tap,
      child: AnimatedBuilder(
        animation: _scale,
        builder: (_, child) => Transform.scale(scale: _scale.value, child: child),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          width: 54,
          height: 54,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: _on
                ? color.withOpacity(0.18)
                : const Color(CyberTheme.bgCard),
            border: Border.all(
              color: _on ? color : const Color(CyberTheme.accentDim),
              width: 1.5,
            ),
            boxShadow: _on
                ? [BoxShadow(color: color.withOpacity(0.35), blurRadius: 12, spreadRadius: 1)]
                : [],
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                widget.icon,
                size: 20,
                color: _on ? color : const Color(CyberTheme.textSecond),
              ),
              const SizedBox(height: 2),
              Text(
                widget.label,
                style: TextStyle(
                  fontSize: 7,
                  color: _on ? color : const Color(CyberTheme.textSecond),
                  fontFamily: 'monospace',
                  letterSpacing: 0.5,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _anim.dispose();
    super.dispose();
  }
}

// ── Momentary Horn / Special button ──────────────────────────
class CyberMomentaryButton extends StatefulWidget {
  final IconData icon;
  final String label;
  final String cmd;
  final ValueChanged<String> onSend;
  final Color? color;

  const CyberMomentaryButton({
    super.key,
    required this.icon,
    required this.label,
    required this.cmd,
    required this.onSend,
    this.color,
  });

  @override
  State<CyberMomentaryButton> createState() => _CyberMomentaryButtonState();
}

class _CyberMomentaryButtonState extends State<CyberMomentaryButton>
    with SingleTickerProviderStateMixin {
  bool _pressed = false;
  late AnimationController _anim;

  @override
  void initState() {
    super.initState();
    _anim = AnimationController(vsync: this, duration: const Duration(milliseconds: 100));
  }

  void _down() {
    setState(() => _pressed = true);
    _anim.forward();
    widget.onSend(widget.cmd);
    Vibration.vibrate(duration: 20);
  }

  void _up() {
    setState(() => _pressed = false);
    _anim.reverse();
  }

  @override
  Widget build(BuildContext context) {
    final color = widget.color ?? const Color(CyberTheme.warning);
    return GestureDetector(
      onTapDown: (_) => _down(),
      onTapUp:   (_) => _up(),
      onTapCancel: _up,
      child: AnimatedBuilder(
        animation: _anim,
        builder: (_, child) => Transform.scale(
          scale: 1.0 - (_anim.value * 0.12),
          child: child,
        ),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 100),
          width: 54,
          height: 54,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: _pressed ? color.withOpacity(0.22) : const Color(CyberTheme.bgCard),
            border: Border.all(color: color.withOpacity(_pressed ? 1.0 : 0.6), width: 1.5),
            boxShadow: _pressed
                ? [BoxShadow(color: color.withOpacity(0.4), blurRadius: 14)]
                : [],
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(widget.icon, size: 20, color: color),
              const SizedBox(height: 2),
              Text(
                widget.label,
                style: TextStyle(fontSize: 7, color: color, fontFamily: 'monospace'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _anim.dispose();
    super.dispose();
  }
}
