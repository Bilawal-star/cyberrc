// lib/widgets/cyber_joystick.dart
import 'package:flutter/material.dart';
import 'dart:math' as math;
import '../config/commands.dart';

class CyberJoystick extends StatefulWidget {
  final String label;
  final bool isMovement;       // true = left stick (F/B/L/R), false = right (steer)
  final ValueChanged<String> onCommand;
  final VoidCallback? onRelease;

  const CyberJoystick({
    super.key,
    required this.label,
    required this.isMovement,
    required this.onCommand,
    this.onRelease,
  });

  @override
  State<CyberJoystick> createState() => _CyberJoystickState();
}

class _CyberJoystickState extends State<CyberJoystick>
    with SingleTickerProviderStateMixin {
  Offset _knob = Offset.zero;
  String _activeCmd = '';
  late AnimationController _pulseCtrl;
  late Animation<double> _pulse;

  static const double _size     = 140.0;
  static const double _knobSize = 52.0;
  static const double _deadzone = 0.2;

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1200))
      ..repeat(reverse: true);
    _pulse = Tween(begin: 0.85, end: 1.0).animate(
      CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut),
    );
  }

  void _handleDrag(DragUpdateDetails d, BoxConstraints constraints) {
    final center = Offset(_size / 2, _size / 2);
    final raw    = d.localPosition - center;
    final dist   = raw.distance;
    final max    = _size / 2 - _knobSize / 2 - 4;
    final clamped = dist > max ? raw * (max / dist) : raw;

    setState(() => _knob = clamped);

    final nx = clamped.dx / max; // -1..1
    final ny = clamped.dy / max; // -1..1 (positive = down = backward)

    final absX = nx.abs();
    final absY = ny.abs();

    if (absX < _deadzone && absY < _deadzone) {
      _emit(RCCommands.stop);
      return;
    }

    String cmd;
    if (widget.isMovement) {
      // 8-direction movement mapping
      if (absY > absX) {
        cmd = ny < 0 ? RCCommands.forward : RCCommands.backward;
      } else {
        cmd = nx < 0 ? RCCommands.left : RCCommands.right;
      }
      // Diagonal zone (both axes > 0.4)
      if (absX > 0.4 && absY > 0.4) {
        if (ny < 0 && nx < 0) cmd = RCCommands.forwardLeft;
        else if (ny < 0 && nx > 0) cmd = RCCommands.forwardRight;
        else if (ny > 0 && nx < 0) cmd = RCCommands.backwardLeft;
        else cmd = RCCommands.backwardRight;
      }
    } else {
      // Right joystick: steering only (L/R)
      cmd = nx < 0 ? RCCommands.left : RCCommands.right;
    }
    _emit(cmd);
  }

  void _emit(String cmd) {
    if (cmd != _activeCmd) {
      _activeCmd = cmd;
      widget.onCommand(cmd);
    }
  }

  void _handleRelease() {
    setState(() {
      _knob = Offset.zero;
      _activeCmd = '';
    });
    widget.onCommand(RCCommands.stop);
    widget.onRelease?.call();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          widget.label,
          style: TextStyle(
            color: const Color(CyberTheme.textSecond),
            fontSize: 10,
            fontFamily: 'monospace',
            letterSpacing: 2,
          ),
        ),
        const SizedBox(height: 6),
        GestureDetector(
          onPanUpdate: (d) => _handleDrag(
            d,
            BoxConstraints.tight(const Size(_size, _size)),
          ),
          onPanEnd:    (_) => _handleRelease(),
          onPanCancel: _handleRelease,
          child: SizedBox(
            width: _size,
            height: _size,
            child: AnimatedBuilder(
              animation: _pulse,
              builder: (_, __) => CustomPaint(
                painter: _JoystickPainter(
                  knob:     _knob,
                  pulse:    _activeCmd.isNotEmpty ? 1.0 : _pulse.value,
                  active:   _activeCmd.isNotEmpty,
                  knobSize: _knobSize,
                  size:     _size,
                ),
              ),
            ),
          ),
        ),
        const SizedBox(height: 4),
        AnimatedContainer(
          duration: const Duration(milliseconds: 150),
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
          decoration: BoxDecoration(
            color: _activeCmd.isNotEmpty
                ? const Color(CyberTheme.accent).withOpacity(0.2)
                : Colors.transparent,
            borderRadius: BorderRadius.circular(4),
          ),
          child: Text(
            _activeCmd.isEmpty ? '—' : _activeCmd,
            style: TextStyle(
              color: _activeCmd.isNotEmpty
                  ? const Color(CyberTheme.accent)
                  : const Color(CyberTheme.textSecond),
              fontSize: 13,
              fontWeight: FontWeight.bold,
              fontFamily: 'monospace',
              letterSpacing: 3,
            ),
          ),
        ),
      ],
    );
  }

  @override
  void dispose() {
    _pulseCtrl.dispose();
    super.dispose();
  }
}

class _JoystickPainter extends CustomPainter {
  final Offset knob;
  final double pulse;
  final bool   active;
  final double knobSize;
  final double size;

  const _JoystickPainter({
    required this.knob,
    required this.pulse,
    required this.active,
    required this.knobSize,
    required this.size,
  });

  @override
  void paint(Canvas canvas, Size sz) {
    final center = Offset(sz.width / 2, sz.height / 2);
    final accent = const Color(CyberTheme.accent);
    final accentDim = const Color(CyberTheme.accentDim);

    // Well
    canvas.drawCircle(
      center,
      sz.width / 2,
      Paint()..color = const Color(CyberTheme.joystickBg),
    );

    // Outer ring glow
    canvas.drawCircle(
      center,
      sz.width / 2 - 1,
      Paint()
        ..color = accentDim.withOpacity(0.5 * pulse)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.5
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 4),
    );

    // Cross-hair guide lines
    final guidePaint = Paint()
      ..color = accentDim.withOpacity(0.25)
      ..strokeWidth = 0.8;
    canvas.drawLine(Offset(center.dx, 8), Offset(center.dx, sz.height - 8), guidePaint);
    canvas.drawLine(Offset(8, center.dy), Offset(sz.width - 8, center.dy), guidePaint);

    // Direction arrows (subtle)
    _drawArrow(canvas, center, 0, sz.width / 2 - 14);    // up
    _drawArrow(canvas, center, math.pi, sz.width / 2 - 14); // down
    _drawArrow(canvas, center, -math.pi / 2, sz.width / 2 - 14); // left
    _drawArrow(canvas, center, math.pi / 2, sz.width / 2 - 14);  // right

    // Knob shadow
    final kPos = center + knob;
    canvas.drawCircle(
      kPos + const Offset(0, 3),
      knobSize / 2,
      Paint()..color = Colors.black.withOpacity(0.5),
    );

    // Knob body
    final knobPaint = Paint()
      ..shader = RadialGradient(colors: [
        active ? accent : const Color(CyberTheme.joystickKnob),
        accentDim,
      ]).createShader(Rect.fromCircle(center: kPos, radius: knobSize / 2));
    canvas.drawCircle(kPos, knobSize / 2, knobPaint);

    // Knob glow
    if (active) {
      canvas.drawCircle(
        kPos,
        knobSize / 2 + 4,
        Paint()
          ..color = accent.withOpacity(0.3)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8),
      );
    }

    // Knob center dot
    canvas.drawCircle(kPos, 4, Paint()..color = Colors.white.withOpacity(0.6));
  }

  void _drawArrow(Canvas canvas, Offset center, double angle, double dist) {
    final x = center.dx + math.cos(angle) * dist;
    final y = center.dy + math.sin(angle) * dist;
    final paint = Paint()
      ..color = const Color(CyberTheme.accentDim).withOpacity(0.4)
      ..strokeWidth = 1
      ..style = PaintingStyle.stroke;
    final path = Path()
      ..moveTo(x + math.cos(angle + math.pi / 2) * 5,
               y + math.sin(angle + math.pi / 2) * 5)
      ..lineTo(x + math.cos(angle) * 6, y + math.sin(angle) * 6)
      ..lineTo(x + math.cos(angle - math.pi / 2) * 5,
               y + math.sin(angle - math.pi / 2) * 5);
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(_JoystickPainter old) =>
      old.knob != knob || old.pulse != pulse || old.active != active;
}
