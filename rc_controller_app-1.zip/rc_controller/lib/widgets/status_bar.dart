// lib/widgets/status_bar.dart
import 'package:flutter/material.dart';
import '../config/commands.dart';
import '../services/bluetooth_service.dart';

class CyberStatusBar extends StatelessWidget {
  final TelemetryData telemetry;
  final bool connected;
  final String deviceName;
  final VoidCallback onConnectTap;

  const CyberStatusBar({
    super.key,
    required this.telemetry,
    required this.connected,
    required this.deviceName,
    required this.onConnectTap,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        // ── Battery ────────────────────────────────────────
        _StatusPill(
          icon: Icons.battery_charging_full_rounded,
          label: '${telemetry.batteryPct.toStringAsFixed(0)}%',
          color: _batteryColor(telemetry.batteryPct),
        ),
        const SizedBox(width: 8),
        // ── Speed ──────────────────────────────────────────
        _StatusPill(
          icon: Icons.speed_rounded,
          label: '${telemetry.speedKmh.toStringAsFixed(0)} Km/h',
          color: const Color(CyberTheme.accent),
        ),
        const Spacer(),
        // ── Connection status ──────────────────────────────
        GestureDetector(
          onTap: onConnectTap,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 300),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: connected
                  ? const Color(CyberTheme.accent).withOpacity(0.15)
                  : const Color(CyberTheme.danger).withOpacity(0.15),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: connected
                    ? const Color(CyberTheme.accent)
                    : const Color(CyberTheme.danger),
                width: 1,
              ),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  connected ? Icons.bluetooth_connected : Icons.bluetooth_disabled,
                  size: 14,
                  color: connected
                      ? const Color(CyberTheme.accent)
                      : const Color(CyberTheme.danger),
                ),
                const SizedBox(width: 6),
                Text(
                  connected ? deviceName.split(' ').first : 'CONNECT',
                  style: TextStyle(
                    color: connected
                        ? const Color(CyberTheme.accent)
                        : const Color(CyberTheme.danger),
                    fontSize: 11,
                    fontFamily: 'monospace',
                    letterSpacing: 1.5,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Color _batteryColor(double pct) {
    if (pct > 50) return const Color(CyberTheme.accent);
    if (pct > 20) return const Color(CyberTheme.warning);
    return const Color(CyberTheme.danger);
  }
}

class _StatusPill extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;

  const _StatusPill({required this.icon, required this.label, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: const Color(CyberTheme.bgCard),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withOpacity(0.4), width: 1),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 13, color: color),
          const SizedBox(width: 5),
          Text(
            label,
            style: TextStyle(
              color: color,
              fontSize: 12,
              fontFamily: 'monospace',
              fontWeight: FontWeight.bold,
              letterSpacing: 0.5,
            ),
          ),
        ],
      ),
    );
  }
}
