// lib/services/bluetooth_service.dart
import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart' as ble;
import 'package:flutter_bluetooth_serial/flutter_bluetooth_serial.dart' as classic;

// ── Connection type enum ───────────────────────────────────────
enum BtType { ble, classic }

// ── Telemetry data from robot ─────────────────────────────────
class TelemetryData {
  final double batteryPct;   // 0–100
  final double speedKmh;     // km/h

  const TelemetryData({this.batteryPct = 0, this.speedKmh = 0});

  factory TelemetryData.fromString(String raw) {
    // Expected format from ESP32: "B:85,S:20" (battery, speed)
    try {
      final parts = <String, double>{};
      for (final seg in raw.split(',')) {
        final kv = seg.split(':');
        if (kv.length == 2) parts[kv[0].trim()] = double.tryParse(kv[1].trim()) ?? 0;
      }
      return TelemetryData(
        batteryPct: parts['B'] ?? 0,
        speedKmh:   parts['S'] ?? 0,
      );
    } catch (_) {
      return const TelemetryData();
    }
  }
}

// ── Main Bluetooth service ────────────────────────────────────
class RCBluetoothService extends ChangeNotifier {
  // ── State ────────────────────────────────────────────────
  bool _connected         = false;
  String _deviceName      = '';
  BtType _btType          = BtType.ble;
  TelemetryData _telemetry = const TelemetryData();
  String _statusMsg       = 'Disconnected';
  bool _scanning          = false;

  bool          get connected    => _connected;
  String        get deviceName   => _deviceName;
  TelemetryData get telemetry    => _telemetry;
  String        get statusMsg    => _statusMsg;
  bool          get scanning     => _scanning;

  // ── BLE internals ────────────────────────────────────────
  ble.BluetoothDevice?         _bleDevice;
  ble.BluetoothCharacteristic? _txChar;      // write  (phone → robot)
  StreamSubscription?          _notifySub;
  
  // Standard BLE Serial UUIDs (matches most ESP32 BLE UART sketches)
  static const _serviceUuid = '6E400001-B5A3-F393-E0A9-E50E24DCCA9E';
  static const _txUuid      = '6E400002-B5A3-F393-E0A9-E50E24DCCA9E';
  static const _rxUuid      = '6E400003-B5A3-F393-E0A9-E50E24DCCA9E';

  // ── Classic BT internals ─────────────────────────────────
  classic.BluetoothConnection? _classicConn;

  // ─────────────────────────────────────────────────────────
  //  SCAN  (BLE)
  // ─────────────────────────────────────────────────────────
  Future<List<ble.ScanResult>> scanBLE({int seconds = 4}) async {
    _scanning = true; notifyListeners();
    final results = <ble.ScanResult>[];
    await ble.FlutterBluePlus.startScan(timeout: Duration(seconds: seconds));
    await for (final r in ble.FlutterBluePlus.scanResults) {
      for (final res in r) {
        if (!results.any((e) => e.device.remoteId == res.device.remoteId)) {
          results.add(res);
        }
      }
    }
    _scanning = false; notifyListeners();
    return results;
  }

  // ─────────────────────────────────────────────────────────
  //  CONNECT BLE
  // ─────────────────────────────────────────────────────────
  Future<bool> connectBLE(ble.BluetoothDevice device) async {
    try {
      _statusMsg = 'Connecting BLE…'; notifyListeners();
      await device.connect(autoConnect: false);
      _bleDevice = device;

      final services = await device.discoverServices();
      for (final svc in services) {
        if (svc.uuid.toString().toUpperCase().contains('6E400001')) {
          for (final ch in svc.characteristics) {
            final u = ch.uuid.toString().toUpperCase();
            if (u.contains('6E400002')) _txChar = ch;
            if (u.contains('6E400003')) {
              await ch.setNotifyValue(true);
              _notifySub = ch.onValueReceived.listen(_onBLEData);
            }
          }
        }
      }

      _btType = BtType.ble;
      _connected = true;
      _deviceName = device.platformName;
      _statusMsg = 'Connected: $_deviceName';
      notifyListeners();
      return true;
    } catch (e) {
      _statusMsg = 'BLE Error: $e';
      notifyListeners();
      return false;
    }
  }

  // ─────────────────────────────────────────────────────────
  //  CONNECT CLASSIC (HC-05)
  // ─────────────────────────────────────────────────────────
  Future<bool> connectClassic(String address) async {
    try {
      _statusMsg = 'Connecting HC-05…'; notifyListeners();
      _classicConn = await classic.BluetoothConnection.toAddress(address);
      _classicConn!.input!.listen(_onClassicData);

      _btType = BtType.classic;
      _connected = true;
      _deviceName = address;
      _statusMsg = 'Connected: $address';
      notifyListeners();
      return true;
    } catch (e) {
      _statusMsg = 'Classic BT Error: $e';
      notifyListeners();
      return false;
    }
  }

  // ─────────────────────────────────────────────────────────
  //  SEND COMMAND
  // ─────────────────────────────────────────────────────────
  Future<void> sendCommand(String cmd) async {
    if (!_connected) return;
    final bytes = utf8.encode(cmd);
    try {
      if (_btType == BtType.ble && _txChar != null) {
        await _txChar!.write(bytes, withoutResponse: true);
      } else if (_btType == BtType.classic && _classicConn != null) {
        _classicConn!.output.add(Uint8List.fromList(bytes));
        await _classicConn!.output.allSent;
      }
    } catch (e) {
      debugPrint('Send error: $e');
    }
  }

  // ─────────────────────────────────────────────────────────
  //  DATA RECEIVERS
  // ─────────────────────────────────────────────────────────
  void _onBLEData(List<int> data) {
    final raw = utf8.decode(data, allowMalformed: true);
    _parseTelemetry(raw);
  }

  void _onClassicData(Uint8List data) {
    final raw = utf8.decode(data, allowMalformed: true);
    _parseTelemetry(raw);
  }

  void _parseTelemetry(String raw) {
    if (raw.contains('B:') || raw.contains('S:')) {
      _telemetry = TelemetryData.fromString(raw);
      notifyListeners();
    }
  }

  // ─────────────────────────────────────────────────────────
  //  DISCONNECT
  // ─────────────────────────────────────────────────────────
  Future<void> disconnect() async {
    _notifySub?.cancel();
    await _bleDevice?.disconnect();
    _classicConn?.finish();
    _connected = false;
    _deviceName = '';
    _statusMsg = 'Disconnected';
    notifyListeners();
  }

  @override
  void dispose() {
    disconnect();
    super.dispose();
  }
}
