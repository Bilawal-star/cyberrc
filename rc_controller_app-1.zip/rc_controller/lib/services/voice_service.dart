// lib/services/voice_service.dart
import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:speech_to_text/speech_to_text.dart';
import 'package:flutter_tts/flutter_tts.dart';
import '../config/commands.dart';

enum VoiceState {
  idle,          // not listening
  awake,         // wake word detected, listening for command
  processing,    // matching command
}

class VoiceService extends ChangeNotifier {
  final SpeechToText  _stt  = SpeechToText();
  final FlutterTts    _tts  = FlutterTts();

  VoiceState  _state       = VoiceState.idle;
  String      _lastWords   = '';
  String      _lastCommand = '';
  bool        _available   = false;
  Timer?      _awakeTimer;

  VoiceState  get state       => _state;
  String      get lastWords   => _lastWords;
  String      get lastCommand => _lastCommand;
  bool        get available   => _available;

  // Callback: called when a valid RC command is decoded from voice
  Function(String command)? onCommandDetected;

  // ─────────────────────────────────────────────────────────
  //  INIT
  // ─────────────────────────────────────────────────────────
  Future<void> initialize() async {
    _available = await _stt.initialize(
      onError: (e) => debugPrint('STT error: $e'),
    );
    await _tts.setLanguage('en-US');
    await _tts.setSpeechRate(0.5);
    notifyListeners();
  }

  // ─────────────────────────────────────────────────────────
  //  START CONTINUOUS WAKE-WORD LISTENING
  // ─────────────────────────────────────────────────────────
  Future<void> startWakeWordListening() async {
    if (!_available || _state != VoiceState.idle) return;
    _state = VoiceState.idle; notifyListeners();

    _listenContinuous();
  }

  void _listenContinuous() {
    if (!_available) return;
    _stt.listen(
      onResult: _onSpeechResult,
      listenFor: const Duration(seconds: 30),
      pauseFor: const Duration(seconds: 3),
      listenOptions: SpeechListenOptions(
        partialResults: true,
        cancelOnError: false,
        listenMode: ListenMode.deviceDefault,
      ),
    );
  }

  // ─────────────────────────────────────────────────────────
  //  SPEECH RESULT HANDLER
  // ─────────────────────────────────────────────────────────
  void _onSpeechResult(SpeechRecognitionResult result) {
    final words = result.recognizedWords.toLowerCase().trim();
    _lastWords = words;
    notifyListeners();

    if (_state == VoiceState.idle) {
      // Check for wake word
      if (words.contains(VoiceConfig.wakeWord)) {
        _activateAwakeMode();
      }
    } else if (_state == VoiceState.awake && result.finalResult) {
      // Strip wake word if user said "hey robot forward"
      final clean = words.replaceAll(VoiceConfig.wakeWord, '').trim();
      _processVoiceCommand(clean);
    }
  }

  // ─────────────────────────────────────────────────────────
  //  WAKE WORD DETECTED
  // ─────────────────────────────────────────────────────────
  void _activateAwakeMode() {
    _state = VoiceState.awake;
    notifyListeners();

    _tts.speak('Ready');

    // Auto-timeout after VoiceConfig.listenSecs seconds
    _awakeTimer?.cancel();
    _awakeTimer = Timer(Duration(seconds: VoiceConfig.listenSecs), () {
      if (_state == VoiceState.awake) {
        _state = VoiceState.idle;
        notifyListeners();
        _listenContinuous(); // restart background listening
      }
    });
  }

  // ─────────────────────────────────────────────────────────
  //  MATCH VOICE → RC COMMAND
  // ─────────────────────────────────────────────────────────
  void _processVoiceCommand(String words) {
    _state = VoiceState.processing; notifyListeners();

    String? matched;
    // Try exact match first
    matched = RCCommands.voiceMap[words];

    // Fuzzy: check if spoken words contain any key
    if (matched == null) {
      for (final entry in RCCommands.voiceMap.entries) {
        if (words.contains(entry.key)) {
          matched = entry.value;
          break;
        }
      }
    }

    if (matched != null) {
      _lastCommand = matched;
      onCommandDetected?.call(matched);
      _tts.speak(_commandToSpeech(matched));
    } else {
      _tts.speak('Command not recognized');
    }

    // Return to idle listening
    Future.delayed(const Duration(milliseconds: 800), () {
      _state = VoiceState.idle;
      notifyListeners();
      _listenContinuous();
    });
  }

  // ─────────────────────────────────────────────────────────
  //  MANUAL TRIGGER (tap-to-speak button)
  // ─────────────────────────────────────────────────────────
  Future<void> triggerManualListen() async {
    if (!_available) return;
    _activateAwakeMode();
  }

  // ─────────────────────────────────────────────────────────
  //  STOP
  // ─────────────────────────────────────────────────────────
  Future<void> stop() async {
    _awakeTimer?.cancel();
    await _stt.stop();
    _state = VoiceState.idle;
    notifyListeners();
  }

  String _commandToSpeech(String cmd) {
    const lookup = {
      'F': 'Forward',  'B': 'Reverse',  'L': 'Left',  'R': 'Right',
      'S': 'Stop',     'U': 'Lights on','u': 'Lights off',
      'Y': 'Beep',     'X': 'Hazard',   'x': 'Hazard off',
    };
    return lookup[cmd] ?? cmd;
  }

  @override
  void dispose() {
    _awakeTimer?.cancel();
    _stt.stop();
    super.dispose();
  }
}
