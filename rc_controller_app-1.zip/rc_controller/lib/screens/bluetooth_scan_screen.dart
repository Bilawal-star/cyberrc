// lib/screens/bluetooth_scan_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart' as ble;
import 'package:flutter_bluetooth_serial/flutter_bluetooth_serial.dart' as classic;
import '../services/bluetooth_service.dart';
import '../config/commands.dart';

class BluetoothScanScreen extends StatefulWidget {
  const BluetoothScanScreen({super.key});
  @override
  State<BluetoothScanScreen> createState() => _BluetoothScanScreenState();
}

class _BluetoothScanScreenState extends State<BluetoothScanScreen> {
  List<ble.ScanResult>      _bleResults   = [];
  List<classic.BluetoothDevice> _classicDevs = [];
  bool _scanning = false;
  String _mode = 'BLE'; // 'BLE' or 'CLASSIC'

  @override
  void initState() {
    super.initState();
    _requestPermissions();
  }

  Future<void> _requestPermissions() async {
    await [
      Permission.bluetooth,
      Permission.bluetoothConnect,
      Permission.bluetoothScan,
      Permission.locationWhenInUse,
      Permission.microphone,
    ].request();
  }

  Future<void> _scan() async {
    final svc = context.read<RCBluetoothService>();
    setState(() { _scanning = true; _bleResults = []; _classicDevs = []; });

    if (_mode == 'BLE') {
      final res = await svc.scanBLE();
      setState(() { _bleResults = res; _scanning = false; });
    } else {
      final bonded = await classic.FlutterBluetoothSerial.instance.getBondedDevices();
      setState(() { _classicDevs = bonded; _scanning = false; });
    }
  }

  @override
  Widget build(BuildContext context) {
    final svc = context.watch<RCBluetoothService>();

    return Scaffold(
      backgroundColor: const Color(CyberTheme.bgPrimary),
      appBar: AppBar(
        backgroundColor: const Color(CyberTheme.bgCard),
        title: Text(
          'CONNECT DEVICE',
          style: TextStyle(
            color: const Color(CyberTheme.accent),
            fontFamily: 'monospace',
            letterSpacing: 3,
            fontSize: 14,
          ),
        ),
        centerTitle: true,
        actions: [
          // BLE / Classic toggle
          Container(
            margin: const EdgeInsets.only(right: 12),
            child: Row(
              children: ['BLE', 'CLASSIC'].map((m) {
                final active = m == _mode;
                return GestureDetector(
                  onTap: () => setState(() => _mode = m),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    margin: const EdgeInsets.only(left: 4),
                    decoration: BoxDecoration(
                      color: active
                          ? const Color(CyberTheme.accent).withOpacity(0.2)
                          : Colors.transparent,
                      borderRadius: BorderRadius.circular(6),
                      border: Border.all(
                        color: active
                            ? const Color(CyberTheme.accent)
                            : const Color(CyberTheme.accentDim),
                      ),
                    ),
                    child: Text(
                      m,
                      style: TextStyle(
                        color: active
                            ? const Color(CyberTheme.accent)
                            : const Color(CyberTheme.textSecond),
                        fontSize: 10,
                        fontFamily: 'monospace',
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
          ),
        ],
      ),
      body: Column(
        children: [
          // Status
          Container(
            padding: const EdgeInsets.all(12),
            color: const Color(CyberTheme.bgPanel),
            child: Text(
              svc.statusMsg,
              style: TextStyle(
                color: svc.connected
                    ? const Color(CyberTheme.accent)
                    : const Color(CyberTheme.textSecond),
                fontFamily: 'monospace',
                fontSize: 12,
              ),
            ),
          ),

          // Device list
          Expanded(
            child: _mode == 'BLE'
                ? _buildBLEList(svc)
                : _buildClassicList(svc),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _scanning ? null : _scan,
        backgroundColor: const Color(CyberTheme.accent),
        foregroundColor: const Color(CyberTheme.bgPrimary),
        icon: _scanning
            ? const SizedBox(
                width: 18,
                height: 18,
                child: CircularProgressIndicator(strokeWidth: 2, color: Colors.black),
              )
            : const Icon(Icons.radar),
        label: Text(
          _scanning ? 'SCANNING…' : 'SCAN',
          style: const TextStyle(fontFamily: 'monospace', fontWeight: FontWeight.bold, letterSpacing: 2),
        ),
      ),
    );
  }

  Widget _buildBLEList(RCBluetoothService svc) {
    if (_bleResults.isEmpty) {
      return Center(
        child: Text(
          'No BLE devices found.\nTap SCAN to search.',
          textAlign: TextAlign.center,
          style: TextStyle(color: const Color(CyberTheme.textSecond), fontFamily: 'monospace'),
        ),
      );
    }
    return ListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: _bleResults.length,
      itemBuilder: (_, i) {
        final r = _bleResults[i];
        final name = r.device.platformName.isNotEmpty ? r.device.platformName : 'Unknown';
        return _DeviceTile(
          name: name,
          subtitle: r.device.remoteId.toString(),
          rssi: r.rssi,
          onTap: () async {
            final ok = await svc.connectBLE(r.device);
            if (ok && mounted) Navigator.pop(context);
          },
        );
      },
    );
  }

  Widget _buildClassicList(RCBluetoothService svc) {
    if (_classicDevs.isEmpty) {
      return Center(
        child: Text(
          'No paired devices.\nPair HC-05 in phone settings first.',
          textAlign: TextAlign.center,
          style: TextStyle(color: const Color(CyberTheme.textSecond), fontFamily: 'monospace'),
        ),
      );
    }
    return ListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: _classicDevs.length,
      itemBuilder: (_, i) {
        final d = _classicDevs[i];
        return _DeviceTile(
          name: d.name ?? 'Unknown',
          subtitle: d.address,
          rssi: null,
          onTap: () async {
            final ok = await svc.connectClassic(d.address);
            if (ok && mounted) Navigator.pop(context);
          },
        );
      },
    );
  }
}

class _DeviceTile extends StatelessWidget {
  final String name;
  final String subtitle;
  final int? rssi;
  final VoidCallback onTap;

  const _DeviceTile({
    required this.name,
    required this.subtitle,
    required this.rssi,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: const Color(CyberTheme.bgCard),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: const Color(CyberTheme.accentDim), width: 1),
        ),
        child: Row(
          children: [
            const Icon(Icons.bluetooth, color: Color(CyberTheme.accent), size: 20),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    name,
                    style: const TextStyle(
                      color: Color(CyberTheme.textPrimary),
                      fontFamily: 'monospace',
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                    subtitle,
                    style: TextStyle(
                      color: const Color(CyberTheme.textSecond),
                      fontFamily: 'monospace',
                      fontSize: 10,
                    ),
                  ),
                ],
              ),
            ),
            if (rssi != null)
              Text(
                '$rssi dBm',
                style: TextStyle(
                  color: const Color(CyberTheme.accentDim),
                  fontFamily: 'monospace',
                  fontSize: 10,
                ),
              ),
            const SizedBox(width: 8),
            const Icon(Icons.arrow_forward_ios, color: Color(CyberTheme.accent), size: 14),
          ],
        ),
      ),
    );
  }
}
