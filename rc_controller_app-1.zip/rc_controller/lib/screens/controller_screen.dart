// lib/screens/controller_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../config/commands.dart';
import '../services/bluetooth_service.dart';
import '../services/voice_service.dart';
import '../widgets/cyber_joystick.dart';
import '../widgets/cyber_toggle_button.dart';
import '../widgets/status_bar.dart';
import 'bluetooth_scan_screen.dart';

class ControllerScreen extends StatefulWidget {
  const ControllerScreen({super.key});
  @override
  State<ControllerScreen> createState() => _ControllerScreenState();
}

class _ControllerScreenState extends State<ControllerScreen>
    with TickerProviderStateMixin {
  late AnimationController _gridCtrl;
  late AnimationController _voiceRingCtrl;
  bool _voiceModeOn = false;

  @override
  void initState() {
    super.initState();
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);

    // Ambient grid animation
    _gridCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 8),
    )..repeat();

    // Voice ring pulse
    _voiceRingCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );

    // Wire voice → BT
    final voice = context.read<VoiceService>();
    final bt    = context.read<RCBluetoothService>();
    voice.onCommandDetected = (cmd) => bt.sendCommand(cmd);
    voice.initialize();
  }

  void _send(String cmd) {
    HapticFeedback.selectionClick();
    context.read<RCBluetoothService>().sendCommand(cmd);
  }

  void _toggleVoice() async {
    final voice = context.read<VoiceService>();
    setState(() => _voiceModeOn = !_voiceModeOn);
    if (_voiceModeOn) {
      _voiceRingCtrl.repeat(reverse: true);
      await voice.startWakeWordListening();
    } else {
      _voiceRingCtrl.stop();
      _voiceRingCtrl.reset();
      await voice.stop();
    }
  }

  @override
  Widget build(BuildContext context) {
    final bt    = context.watch<RCBluetoothService>();
    final voice = context.watch<VoiceService>();
    final size  = MediaQuery.of(context).size;

    return Scaffold(
      backgroundColor: const Color(CyberTheme.bgPrimary),
      body: Stack(
        children: [
          // ── Ambient grid background ───────────────────────
          _AmbientGrid(controller: _gridCtrl),

          // ── Main layout ───────────────────────────────────
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              child: Column(
                children: [
                  // STATUS BAR
                  CyberStatusBar(
                    telemetry:  bt.telemetry,
                    connected:  bt.connected,
                    deviceName: bt.deviceName,
                    onConnectTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const BluetoothScanScreen()),
                    ),
                  ),

                  const SizedBox(height: 10),

                  // CONTROL AREA
                  Expanded(
                    child: Row(
                      children: [
                        // ── LEFT JOYSTICK (Movement) ──────────────────────────────
                        CyberJoystick(
                          label: 'DRIVE',
                          isMovement: true,
                          onCommand: _send,
                        ),

                        // ── CENTRE PANEL ──────────────────────────────────────────
                        Expanded(child: _buildCentrePanel(voice, size)),

                        // ── RIGHT JOYSTICK (Steering) ─────────────────────────────
                        CyberJoystick(
                          label: 'STEER',
                          isMovement: false,
                          onCommand: _send,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ─────────────────────────────────────────────────────────
  //  CENTRE PANEL
  // ─────────────────────────────────────────────────────────
  Widget _buildCentrePanel(VoiceService voice, Size size) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        // ── Top row: Lights row ─────────────────────────
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CyberToggleButton(
              icon: Icons.light_mode_outlined,
              label: 'HEAD',
              cmdOn:  RCCommands.headlightOn,
              cmdOff: RCCommands.headlightOff,
              onSend: _send,
            ),
            const SizedBox(width: 8),
            CyberToggleButton(
              icon: Icons.light_outlined,
              label: 'TAIL',
              cmdOn:  RCCommands.taillightOn,
              cmdOff: RCCommands.taillightOff,
              onSend: _send,
            ),
            const SizedBox(width: 8),
            CyberToggleButton(
              icon: Icons.local_parking_outlined,
              label: 'PARK',
              cmdOn:  RCCommands.parkingOn,
              cmdOff: RCCommands.parkingOff,
              onSend: _send,
            ),
            const SizedBox(width: 8),
            CyberToggleButton(
              icon: Icons.warning_amber_outlined,
              label: 'HAZARD',
              cmdOn:  RCCommands.hazardOn,
              cmdOff: RCCommands.hazardOff,
              onSend: _send,
              activeColor: const Color(CyberTheme.warning),
            ),
          ],
        ),

        // ── VOICE BUTTON (centre) ───────────────────────
        _buildVoiceButton(voice),

        // ── Bottom row: Horn + Special + Fn ────────────
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CyberMomentaryButton(
              icon: Icons.campaign_outlined,
              label: 'HORN',
              cmd: RCCommands.horn,
              onSend: _send,
              color: const Color(CyberTheme.warning),
            ),
            const SizedBox(width: 8),
            CyberMomentaryButton(
              icon: Icons.auto_awesome_outlined,
              label: 'SPEC',
              cmd: RCCommands.specialFunc,
              onSend: _send,
              color: const Color(CyberTheme.accent),
            ),
            const SizedBox(width: 8),
            // Custom function buttons 1-4
            ...List.generate(4, (i) {
              final cmds = [
                RCCommands.func1,
                RCCommands.func2,
                RCCommands.func3,
                RCCommands.func4,
              ];
              return Padding(
                padding: const EdgeInsets.only(left: 4),
                child: CyberMomentaryButton(
                  icon: Icons.radio_button_checked,
                  label: 'F${i + 1}',
                  cmd: cmds[i],
                  onSend: _send,
                  color: const Color(CyberTheme.accentDim),
                ),
              );
            }),
          ],
        ),
      ],
    );
  }

  // ─────────────────────────────────────────────────────────
  //  VOICE BUTTON
  // ─────────────────────────────────────────────────────────
  Widget _buildVoiceButton(VoiceService voice) {
    return AnimatedBuilder(
      animation: _voiceRingCtrl,
      builder: (_, child) {
        final ring = _voiceModeOn ? (_voiceRingCtrl.value * 8 + 2) : 2.0;
        final glow = _voiceModeOn ? _voiceRingCtrl.value * 0.5 : 0.0;
        return GestureDetector(
          onTap: _toggleVoice,
          onLongPress: () => context.read<VoiceService>().triggerManualListen(),
          child: Container(
            width: 80,
            height: 80,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: _voiceModeOn
                  ? const Color(CyberTheme.accent).withOpacity(0.15)
                  : const Color(CyberTheme.bgCard),
              border: Border.all(
                color: _voiceModeOn
                    ? const Color(CyberTheme.accent)
                    : const Color(CyberTheme.accentDim),
                width: ring,
              ),
              boxShadow: _voiceModeOn
                  ? [
                      BoxShadow(
                        color: const Color(CyberTheme.accent).withOpacity(glow),
                        blurRadius: 20,
                        spreadRadius: 4,
                      )
                    ]
                  : [],
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // State icon
                Icon(
                  voice.state == VoiceState.awake
                      ? Icons.mic
                      : voice.state == VoiceState.processing
                          ? Icons.psychology_outlined
                          : Icons.mic_none_outlined,
                  size: 26,
                  color: _voiceModeOn
                      ? const Color(CyberTheme.accent)
                      : const Color(CyberTheme.textSecond),
                ),
                const SizedBox(height: 2),
                Text(
                  voice.state == VoiceState.awake
                      ? 'READY'
                      : voice.state == VoiceState.processing
                          ? 'PROC…'
                          : _voiceModeOn
                              ? 'AI ON'
                              : 'AI MIC',
                  style: TextStyle(
                    color: _voiceModeOn
                        ? const Color(CyberTheme.accent)
                        : const Color(CyberTheme.textSecond),
                    fontSize: 8,
                    fontFamily: 'monospace',
                    letterSpacing: 1.5,
                  ),
                ),
                // Last command bubble
                if (voice.lastCommand.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(top: 2),
                    child: Text(
                      voice.lastCommand,
                      style: const TextStyle(
                        color: Color(CyberTheme.accent),
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'monospace',
                      ),
                    ),
                  ),
              ],
            ),
          ),
        );
      },
    );
  }

  @override
  void dispose() {
    SystemChrome.setPreferredOrientations(DeviceOrientation.values);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    _gridCtrl.dispose();
    _voiceRingCtrl.dispose();
    super.dispose();
  }
}

// ─────────────────────────────────────────────────────────
//  AMBIENT GRID (background effect)
// ─────────────────────────────────────────────────────────
class _AmbientGrid extends StatelessWidget {
  final AnimationController controller;
  const _AmbientGrid({required this.controller});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (_, __) => CustomPaint(
        size: MediaQuery.of(context).size,
        painter: _GridPainter(progress: controller.value),
      ),
    );
  }
}

class _GridPainter extends CustomPainter {
  final double progress;
  const _GridPainter({required this.progress});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(CyberTheme.accentDim).withOpacity(0.07)
      ..strokeWidth = 0.5;

    const spacing = 40.0;
    final offset = (progress * spacing) % spacing;

    // Vertical lines
    for (double x = offset; x < size.width; x += spacing) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    // Horizontal lines
    for (double y = offset; y < size.height; y += spacing) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }

    // Horizon glow
    final horizPaint = Paint()
      ..shader = LinearGradient(
        colors: [
          Colors.transparent,
          const Color(CyberTheme.accent).withOpacity(0.04),
          Colors.transparent,
        ],
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height));
    canvas.drawRect(Rect.fromLTWH(0, 0, size.width, size.height), horizPaint);
  }

  @override
  bool shouldRepaint(_GridPainter old) => old.progress != progress;
}
