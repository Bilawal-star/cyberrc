// lib/config/commands.dart
// ============================================================
//  COMMAND DICTIONARY — edit here to remap any control
//  Matches the Controls screen shown in the reference images
// ============================================================

class RCCommands {
  // ── Movement ──────────────────────────────────────────────
  static const String forward        = 'F';
  static const String backward       = 'B';
  static const String left           = 'L';
  static const String right          = 'R';
  static const String forwardLeft    = 'G';
  static const String forwardRight   = 'H';
  static const String backwardLeft   = 'I';
  static const String backwardRight  = 'J';
  static const String stop           = 'S';

  // ── Lights ────────────────────────────────────────────────
  static const String headlightOn    = 'U';
  static const String headlightOff   = 'u';
  static const String taillightOn    = 'V';
  static const String taillightOff   = 'v';
  static const String parkingOn      = 'W';
  static const String parkingOff     = 'w';
  static const String hazardOn       = 'X';
  static const String hazardOff      = 'x';

  // ── Accessories ───────────────────────────────────────────
  static const String horn           = 'Y';
  static const String specialFunc    = 'Z';

  // ── Custom / Other Functions ──────────────────────────────
  static const String func1          = '1';
  static const String func2          = '2';
  static const String func3          = '3';
  static const String func4          = '4';

  // ── Speed Presets (optional) ──────────────────────────────
  static const String speedLow       = 'q';
  static const String speedMed       = 'e';
  static const String speedHigh      = 'r';

  // ── Voice command → RC command mapping ───────────────────
  static const Map<String, String> voiceMap = {
    // Movement
    'forward'        : forward,
    'go forward'     : forward,
    'move forward'   : forward,
    'backward'       : backward,
    'reverse'        : backward,
    'go back'        : backward,
    'left'           : left,
    'turn left'      : left,
    'right'          : right,
    'turn right'     : right,
    'stop'           : stop,
    'halt'           : stop,
    'brake'          : stop,
    'forward left'   : forwardLeft,
    'forward right'  : forwardRight,
    'backward left'  : backwardLeft,
    'backward right' : backwardRight,
    // Lights
    'headlight on'   : headlightOn,
    'headlight off'  : headlightOff,
    'lights on'      : headlightOn,
    'lights off'     : headlightOff,
    'hazard on'      : hazardOn,
    'hazard off'     : hazardOff,
    'parking on'     : parkingOn,
    'parking off'    : parkingOff,
    // Accessories
    'horn'           : horn,
    'beep'           : horn,
    'special'        : specialFunc,
  };
}

// ── App theme tokens ──────────────────────────────────────────
class CyberTheme {
  static const bgPrimary    = 0xFF060D0C;   // near-black green-tinted
  static const bgCard       = 0xFF0D1F1C;   // card surface
  static const bgPanel      = 0xFF112320;   // panel surface
  static const accent       = 0xFF00E5A0;   // neon teal-green  ← signature
  static const accentDim    = 0xFF007A52;   // dimmed accent
  static const danger       = 0xFFFF3B3B;   // red alerts
  static const warning      = 0xFFFFB800;   // amber warnings
  static const textPrimary  = 0xFFE0FFF4;   // near-white
  static const textSecond   = 0xFF608070;   // muted text
  static const joystickBg   = 0xFF0A1A17;   // joystick well
  static const joystickKnob = 0xFF00C087;   // knob
}

// ── Wake word ─────────────────────────────────────────────────
class VoiceConfig {
  static const String wakeWord     = 'hey robot';
  static const int    listenSecs   = 5;      // seconds STT listens after wake
  static const double confidence   = 0.75;   // minimum STT confidence
}
