// lib/main.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'services/bluetooth_service.dart';
import 'services/voice_service.dart';
import 'screens/controller_screen.dart';
import 'config/commands.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.landscapeLeft,
    DeviceOrientation.landscapeRight,
  ]);
  runApp(const CyberRCApp());
}

class CyberRCApp extends StatelessWidget {
  const CyberRCApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => RCBluetoothService()),
        ChangeNotifierProvider(create: (_) => VoiceService()),
      ],
      child: MaterialApp(
        title: 'Cyber RC Controller',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          brightness: Brightness.dark,
          scaffoldBackgroundColor: const Color(CyberTheme.bgPrimary),
          colorScheme: ColorScheme.dark(
            primary:   const Color(CyberTheme.accent),
            secondary: const Color(CyberTheme.accentDim),
            surface:   const Color(CyberTheme.bgCard),
          ),
          // Mono-space feel throughout
          textTheme: const TextTheme(
            bodyMedium: TextStyle(fontFamily: 'monospace', color: Color(CyberTheme.textPrimary)),
          ),
          appBarTheme: const AppBarTheme(
            backgroundColor: Color(CyberTheme.bgCard),
            elevation: 0,
          ),
          useMaterial3: true,
        ),
        home: const ControllerScreen(),
      ),
    );
  }
}
