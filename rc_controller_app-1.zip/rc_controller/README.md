# 🚗 Cyber RC Controller
### AI-Powered Bluetooth RC Car App for ESP32 4WD

---

## 📁 Project Structure

```
rc_controller/
├── lib/
│   ├── config/
│   │   └── commands.dart          ← ALL command mappings (edit here)
│   ├── services/
│   │   ├── bluetooth_service.dart ← BLE + Classic BT handler
│   │   └── voice_service.dart     ← Wake word + STT + TTS
│   ├── widgets/
│   │   ├── cyber_joystick.dart    ← Custom dual joystick
│   │   ├── cyber_toggle_button.dart ← Light/toggle buttons
│   │   └── status_bar.dart        ← Battery + Speed HUD
│   ├── screens/
│   │   ├── controller_screen.dart ← Main dashboard
│   │   └── bluetooth_scan_screen.dart
│   └── main.dart
├── esp32_firmware/
│   └── Bilal_4WD_Car_BLE.ino     ← ESP32 Arduino sketch
└── pubspec.yaml
```

---

## ⚡ Command Protocol

| Command | Character | Description |
|---------|-----------|-------------|
| Forward | `F` | Drive forward |
| Backward | `B` | Drive backward |
| Left | `L` | Spin left |
| Right | `R` | Spin right |
| Forward Left | `G` | Diagonal |
| Forward Right | `H` | Diagonal |
| Backward Left | `I` | Diagonal |
| Backward Right | `J` | Diagonal |
| Stop | `S` | All stop |
| Headlight ON | `U` | LED on |
| Headlight OFF | `u` | LED off |
| Taillight ON | `V` | |
| Taillight OFF | `v` | |
| Parking ON | `W` | |
| Parking OFF | `w` | |
| Hazard ON | `X` | |
| Hazard OFF | `x` | |
| Horn | `Y` | Momentary |
| Special | `Z` | Custom |
| Fn 1–4 | `1`, `2`, `3`, `4` | Custom |

---

## 🎤 Voice Commands (Wake Word: "Hey Robot")

Say **"Hey Robot"** then any of:
- *"forward"* / *"go forward"*
- *"backward"* / *"reverse"*
- *"left"* / *"right"* / *"stop"*
- *"lights on"* / *"lights off"*
- *"hazard on"* / *"horn"*

> Long-press the mic button to trigger voice instantly without wake word.

---

## 📡 Telemetry Format (ESP32 → App)

ESP32 sends every 500ms:
```
B:85,S:20
```
- `B` = battery percentage
- `S` = speed km/h

---

## 🔧 Flutter Setup

```bash
cd rc_controller
flutter pub get
flutter run
```

**Dependencies:**
- `flutter_blue_plus` — BLE (ESP32)
- `flutter_bluetooth_serial` — Classic BT (HC-05)
- `speech_to_text` — Voice STT
- `flutter_tts` — Voice feedback
- `provider` — State management
- `vibration` — Haptic feedback

---

## 🔌 ESP32 Wiring (TB6612FNG)

| ESP32 Pin | TB6612FNG | Function |
|-----------|-----------|----------|
| GPIO 25 | PWMA | Left motor speed |
| GPIO 26 | AIN1 | Left direction 1 |
| GPIO 27 | AIN2 | Left direction 2 |
| GPIO 14 | PWMB | Right motor speed |
| GPIO 12 | BIN1 | Right direction 1 |
| GPIO 13 | BIN2 | Right direction 2 |
| GPIO 33 | STBY | Standby control |
| GPIO 32 | — | Headlight LED |
| GPIO 4 | — | Taillight LED |

---

## 📱 Android Permissions Required

- BLUETOOTH + BLUETOOTH_SCAN + BLUETOOTH_CONNECT
- ACCESS_FINE_LOCATION (BLE scan on Android < 12)
- RECORD_AUDIO (voice commands)

Copy `android_manifest.xml` content into:
`android/app/src/main/AndroidManifest.xml`

---

## 🔄 To Remap Any Control

Edit **`lib/config/commands.dart`** only:
```dart
static const String forward = 'F';   // change 'F' to anything
```
And update `voiceMap` to add new voice phrases.

---

*Built for Bilal_4WD_Car — ESP32 + TB6612FNG + 3S 26650*
